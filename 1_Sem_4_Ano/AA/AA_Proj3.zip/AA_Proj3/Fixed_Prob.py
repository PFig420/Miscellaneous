from collections import Counter
import string
import random
import time
import urllib.request  # the lib that handles the url stuff

def fixed_probability_count(file_name, probability):
    start = time.time()
    text_flag_fpc = False
    counter = {}
    for letter in string.ascii_uppercase:
        counter[letter] = 0
    with urllib.request.urlopen(file_name) as f:
        for line in f:
            line = line.decode('utf-8')
            if "*** S" in line:
                text_flag_fpc = True
            if "*** E" in line:
                break
            if text_flag_fpc:
                if len(line) == 2:
                    continue
                else:
                    for char in line:
                        if random.random() < probability:
                            if char in string.ascii_lowercase or char in string.ascii_uppercase:
                                counter[char.upper()] += 2   

    k = Counter(counter)
    high = k.most_common(3)     
    return high, time.time() - start


links = ["https://www.gutenberg.org/files/62615/62615-0.txt", "https://www.gutenberg.org/cache/epub/30/pg30.txt", "https://www.gutenberg.org/files/62383/62383-0.txt"]
max_en = max_pt = max_fr = 0
avg_en = avg_pt = avg_fr =0
min_en = min_pt = min_fr = 100000000000000000000000000000000000000000000000000000000000000000
avg_time_en = avg_time_pt = avg_time_fr = 0
cen =cpt = cfr = 0
for i in range(2):
    for link in links:
        cnt_fpc, timer = fixed_probability_count(link, 0.5)
        if link == "https://www.gutenberg.org/files/62615/62615-0.txt":
            if cnt_fpc[0][1] > max_fr:
                max_fr = cnt_fpc[0][1]
            if cnt_fpc[0][1] < min_fr:
                min_fr = cnt_fpc[0][1]
            avg_fr += cnt_fpc[0][1]
            avg_time_fr += timer
            cen +=1
        if link == "https://www.gutenberg.org/cache/epub/30/pg30.txt":
            if cnt_fpc[0][1] > max_en:
                max_en = cnt_fpc[0][1]
            if cnt_fpc[0][1] < min_en:
                min_en = cnt_fpc[0][1]
            avg_en += cnt_fpc[0][1]
            avg_time_en += timer
            cpt +=1
        if link == "https://www.gutenberg.org/files/62383/62383-0.txt":
            if cnt_fpc[0][1] > max_pt:
                max_pt = cnt_fpc[0][1]
            if cnt_fpc[0][1] < min_pt:
                min_pt = cnt_fpc[0][1]
            avg_pt += cnt_fpc[0][1]
            avg_time_pt += timer
            cfr +=1
        print(".")
print("EN")
print(max_en)
print(min_en)
print(avg_en/cen)
print(cen)
print(avg_time_en/cen)
print("FR")
print(max_fr)
print(min_fr)
print(avg_fr/cfr)
print(cfr)
print(avg_time_fr/cfr)
print("PT")
print(max_pt)
print(min_pt)
print(avg_pt/cpt)
print(cpt)
print(avg_time_pt/cpt)
