from collections import Counter, defaultdict
import string
import time

import urllib.request



def frequent_count(stream):
    start_exact = time.time()
    operations = 0
    counter = defaultdict(int)
    text_flag = False #Flag that checks if we're reading a Gutenberg header or the actual book
    for line in urllib.request.urlopen(stream):
        line = line.decode('utf-8')
        if "*** S" in line:
            text_flag = True
        if "*** E" in line:
            break
        if text_flag:
            if len(line) == 2:
                continue
            else:
                for item in line:
                    if item in string.ascii_lowercase or item in string.ascii_uppercase:
                        operations +=1
                        item = item.upper()
                        counter[item] += 1
   
    k = Counter(counter)
    high = k.most_common(10)
    print(time.time()-start_exact)
    print(operations)
    return high




links = ["https://www.gutenberg.org/files/62615/62615-0.txt", "https://www.gutenberg.org/cache/epub/30/pg30.txt", "https://www.gutenberg.org/files/62383/62383-0.txt"]
for link in links:
    a = frequent_count(link)
    print(a)
    print()